# Repo Residency and Boundaries

## Recommended Top-Level Separation

Suggested conceptual layout:

```text
/AtlasWorkspace
  /Source
    /Workspace
    /AtlasUI
    /Editor
    /Build
    /Codex
    /Logger
    /AI
    /GitTool
    /ProjectSystem
    /Plugins
  /Docs
  /Tools
  /Assets

/Projects
  /NovaForge
  /OtherProjectExample
```

Exact folders can vary, but the ownership boundaries should stay stable.

## Workspace-Owned Systems

These belong in the generic Workspace/tooling side:
- shell host
- dock framework
- command/shortcut system
- menu/context menu system
- theme/token/style manager
- notification center
- project loader
- asset intake pipeline
- Git app/tool
- build runner/orchestrator
- log packaging and archive handling
- Codex storage/indexing/mirroring
- AtlasAI broker shell integration
- generic viewport/editor framework
- generic outliner/selection/inspector patterns
- editor play mode switching framework
- plugin loading and registration

## Project-Owned Systems

These belong in NovaForge or other loaded projects:
- gameplay ECS components that are game-specific
- farming systems
- space systems
- research systems
- crafting recipes specific to the game
- inventory schemas specific to the game
- HUD/menu flows for the game
- R.I.G. equipment logic
- world generation rules
- fleet systems
- combat systems
- narrative content
- project assets and content definitions

## Borderline Systems

These need careful split design:
- ECS starter pack: generic parts in Workspace/engine support, game data in project
- viewport controls: generic camera/mode tools in Workspace, game possession rules in project
- visual scripting: generic graph/editor in Workspace, project nodes/modules in project
- asset pipeline: generic pipeline in Workspace, project import rules/extensions per project

## Residency Rule of Thumb

Ask:
1. Would this system still make sense if NovaForge vanished?
2. Could another unrelated game/tool use this unchanged?
3. Is the data format generic or tied to one game?

If yes, it likely belongs in Workspace.
If no, it likely belongs in the project layer.
