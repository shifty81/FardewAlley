# AtlasAI, Codex, and Logger Flow

## AtlasAI Role

AtlasAI is the only visible middle-man broker.
External providers should not be exposed directly in the UI.

Preferred flow:
1. Codex / local audit
2. web / search
3. ChatGPT / OpenAI initial model layer
4. optional hidden fallback providers

## Error and Build Flow

All detected errors in logs should be handed to AtlasAI for debugging.

Expected loop:
1. build fails
2. logs are packaged into `.logger`
3. `.logger` is archived into Codex
4. AtlasAI is offered the failure context
5. AtlasAI checks prior fixes/Codex first
6. AtlasAI researches when needed
7. AtlasAI produces markdown change summary and diff
8. user gets explicit Yes/No choice to apply fix

## Codex Role

Codex is the memory and reuse layer for:
- logs
- fixes
- snippets
- validated successful outputs
- assets where practical
- mirrored useful interactions

The direction already locked in:
- pretty much every successful interaction should be mirrored into Codex, subject to validation and deduplication
- visual scripting graphs and successful patterns should become reusable templates
- asset and snippet library should be consolidated through Codex where possible

## Archive Rule

Zip files dropped in the root should be automatically audited.
Loose txt/md and similar root drops should be absorbed into the archive system.
The archive system is intended to be git-ignored once fully implemented.

## Notification/UI Coupling

When AtlasAI finds a candidate fix:
- notification center alerts user
- clicking notification expands into AtlasAI chat window
- diff and change summary are shown there
- user explicitly approves or rejects implementation
