# Gap and Missing Spec Tracker

## Major Missing or Needing Consolidation on Workspace Side

### Architecture / Structure
- final Workspace directory map
- residency matrix with exact target folders
- keep/merge/rewrite/retire inventory
- plugin contract spec
- project loader contract
- build target registration model

### AtlasUI / Shell
- full AtlasUI widget contract set
- docking behavior rules
- shell app lifecycle model
- notification center spec
- tray/expandable AI panel behavior
- modal/popup/window policy
- workspace multi-tool launch routing

### Commands / Input
- full command registry spec
- shortcut routing and rebinding rules
- editor/workspace/game input context separation contract
- play mode transition rules

### Editor Framework
- outliner contract
- selection system contract
- inspector property editing contract
- viewport framework contract
- viewport camera starter implementation
- gizmo/manipulator contract
- undo/redo model

### Build / Logs / Codex / AI
- `.logger` format spec
- Codex ingestion schema
- archive/autotriage root-drop rules
- AtlasAI broker API boundary
- fix proposal/diff format
- validation and promotion rules for Codex memory

### Integrations
- GitHub link flow
- Google link flow
- Drive ingestion flow
- Steam future boundary notes
- repo clone/create workflow in Git tool

## Game-Side Missing Specs Still Mentioned in Prior Planning

### NovaForge
- research domain map
- research entry schema
- activity tracking ledger
- knowledge item / blueprint schema
- research station type spec
- research UI/archive screen
- unlock formula and tier gating rules
- world generation spawn rules
- biome/archetype tables
- structure archetype library
- extensive storage/automation/network specs
- many UI screen contracts

### Stardew-like C++ Vertical Slice
- exact technical pack outputs per phase
- data schema normalization
- multiplayer interaction contract
- save format and migration rules

## Enforcement Need

A repo enforcement pack is still needed to stop drift:
- banned include/use patterns
- allowed path maps
- deprecated symbol checks
- CI validators
- theme/token use enforcement
- phase gate rules
