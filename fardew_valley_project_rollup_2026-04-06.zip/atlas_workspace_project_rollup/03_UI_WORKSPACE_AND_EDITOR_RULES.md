# UI, Workspace, and Editor Rules

## AtlasUI Direction

AtlasUI is the standard UI framework for all development tooling and interfaces.

It should provide:
- panels
- tab bars
- splitters
- toolbars
- buttons
- text inputs
- dropdowns
- menus/context menus
- tooltips
- notifications
- inspector widgets
- outliner/list/tree surfaces
- docking visuals

## Visual Direction

- polished dark mode
- rounded edges and buttons
- consistent panel chrome
- consistent hover/pressed/focus states
- intuitive desktop workflow
- standalone tools launched against the loaded project

## Workspace Shell Direction

Atlas Workspace is an OS-like shell/workspace.
Key rules already established:
- start bar label should be `Atlas`
- start bar should auto-hide when idle or when the editor is loaded
- IDE/tool apps are standalone tools within the shell
- tools should inherit global OS/theme conventions where appropriate

## First-Boot Expectations

First boot should include account linking plans for:
- GitHub
- Google

Planned future integrations:
- Google Drive
- Steam for authoring/deployment/workshop flows

## Intake and Notification Rules

Workspace should support:
- drag-and-drop across shell surfaces
- file-type-aware intake
- tray/notification-center events on intake
- AI chat as primary natural-language interaction layer
- AI surface expanding out from notification/tray area when handling intake/debug tasks

## Editor Interaction Rules

There should be separate bindings for:
- editor context
- workspace/system context
- game context

Specific user preference captured:
- in game: space = jump, ctrl = crouch, shift = sprint
- in editor: space = up, ctrl = down, shift = sprint
- explicit play mode toggle should switch editor/game context and possession

## Priority Lock

Game development work should be pushed back on the roadmap unless explicitly chosen.
AtlasUI/framework/tooling standardization should be moved to the front.
