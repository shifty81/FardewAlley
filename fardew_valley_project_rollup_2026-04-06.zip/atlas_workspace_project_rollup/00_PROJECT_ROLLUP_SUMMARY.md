# Project Rollup Summary

## Executive Direction

Atlas Workspace is now the generic development environment and editor host. It is not the game. It is the tooling platform that loads external projects such as NovaForge for development, editing, build orchestration, asset flow, logging, Codex capture, and AtlasAI brokered assistance.

NovaForge remains a separate game project that is developed through Atlas Workspace. It is logically detachable and should not be treated as core Workspace code. During active development it can be housed in the same larger environment, but the Workspace core must remain generic and free of game-specific logic.

## Primary Strategic Shift

The major correction is this:

- old drift: Workspace and game concepts were repeatedly blending together
- locked direction: Workspace core is generic editor/software infrastructure
- game logic lives in project/plugin space, not in Workspace core

This is the most important architectural rule in the current project state.

## Current Locked Priorities

1. Consolidate and normalize architecture before building too many more systems
2. Push AtlasUI and tooling standardization to the front of the roadmap
3. Keep game development work behind tooling unless explicitly chosen
4. Build the Workspace shell, editor framework, commands, docking, project loading, build/log flow, and Codex/AtlasAI integration first
5. Keep NovaForge and future games loadable into the Workspace rather than fused into core

## What the Workspace Is Supposed to Be

Atlas Workspace should provide:

- generic editor shell
- docking panels and tool windows
- command and shortcut framework
- project loading
- Git integration as its own app/tool
- build orchestration
- log packaging into `.logger` artifacts
- Codex ingestion of useful outputs and reusable interactions
- AtlasAI as the visible broker layer
- drag/drop intake across the shell
- notification center with actionable AI/debug/intake events
- asset and snippet library surfaces
- engine/editor extensibility hooks
- default editor viewport camera behavior

## What the Workspace Should Not Be

Workspace core should not contain:

- game-specific UI contracts
- game-specific progression systems
- game-specific world rules
- NovaForge-specific content logic
- assumptions that the loaded project is a farming game, space game, or any other specific genre

Those belong in the external project layer.

## NovaForge Rollup

NovaForge direction remains broad and ambitious, with multiple strands previously discussed:

- voxel + low-poly hybrid presentation
- FPS-first gameplay
- later fleet command layer
- R.I.G. progression and modular equipment platform
- exploration, industry, survival, ship/base/vehicle systems
- procedural generation and world structure plans
- extensive UI, inventory, crafting, storage, research, and automation plans

At the same time, a parallel native C++ Stardew-like replica track was also being structured with incremental gameplay packs:
- input + movement + interaction
- tools
- inventory
- crafting/resource processing
- storage
- pickup/drop/world item entities
- crop growth/harvest
- day/night and time
- save/load consolidation
- multiplayer interaction later

These two game design streams should not contaminate Workspace core. They are game-side planning streams.

## Main Correction for Repo Execution

Before major new feature expansion:
- normalize naming
- normalize boundaries
- normalize target folders
- normalize ownership of systems
- standardize UI/tooling infrastructure
- establish enforcement

Then build forward from the locked structure.

## Immediate Best Use of This Pack

Use this rollup to audit the repo for:
- architecture drift
- naming drift
- incorrect code residency
- missing core editor/tooling systems
- missing supporting docs/specs
- roadmap disorder
