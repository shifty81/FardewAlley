# NovaForge and Game-Side Rollup

## Important Separation Notice

This file is a rollup of game-side planning only. These systems should not be treated as Workspace core requirements unless a generic editor/tooling layer is being extracted from them.

## NovaForge Locked Game Direction

- 3D FPS is the main play mode
- fleet gameplay is later and secondary
- voxel + low-poly hybrid direction is locked
- voxel layer should be implemented first
- low-poly overlay comes later as the visual shell
- seasons configurable client/server, usually enforced server-side
- default target season length around 6 months
- player suit terminology is `R.I.G.`
- R.I.G. is progression-based and modular
- initial R.I.G. is minimal backpack/frame state with limited life support/HUD
- helmet deploys from back assembly to enable visor and HUD
- modules include utility, armor, shield, and life-support-related systems
- arm modules can unlock wrist terminal and backpack crafting

## Additional NovaForge World/Feature Threads Discussed

- planetary/orbital/space/interior layering
- ruins, caves, asteroid dens, abandoned facilities, anomaly gates
- salvage and reclaim gameplay
- research systems based on learn-by-doing, items, and unlock tracking
- storage, automation, manufacturing, supply lines, drones, NPC/visitor events
- ship/base/vehicle build systems
- voxel-to-low-poly mesh generation pipeline
- broad game UI and management screens

## Parallel Native C++ Stardew-Like Track Discussed

A separate execution line also exists for a native Windows C++ local co-op Stardew-like/Zelda-like vertical slice.

Ordered pack chain already discussed:
1. Input + Movement + Tile Interaction Pack v1
2. Tool System Pack v1
3. Inventory + Item Grant Pack v1
4. Crafting + Resource Processing Pack v1
5. Storage + Container Interaction Pack v1
6. Station UI + Processing Loop Pack v1
7. Placeable Objects + Stations Pack v1
8. Pickup/Drop + World Item Entity Pack v1
9. Crop Growth + Harvest State Pack v1
10. Day/Night + Time System Pack v1
11. Save/Load World Consolidation Pass
12. Multiplayer Interaction Layer later

## Required Handling

Keep these game plans in:
- project docs
- game specs
- project plugin space
- game-specific code folders

Do not wire them directly into generic Workspace core.
