# Implementation Roadmap

## Phase 0: Consolidation First

Before major feature growth:
- complete naming normalization
- complete repo boundary normalization
- complete directory ownership mapping
- retire old drifted terms
- establish enforcement rules
- identify keep / merge / rewrite / retire systems

This should be treated as a structural refactor pass, not optional cleanup.

## Phase 1: Workspace Core Foundation

1. architecture lock
2. theme + token system
3. AtlasUI base widgets
4. command + shortcut system
5. menu + context menu system
6. docking/tab/splitter interaction
7. shell host and app framework
8. outliner/selection/inspector foundations
9. viewport framework and camera contract
10. play mode context switching

## Phase 2: Workspace Services

1. project loader
2. plugin/extensibility layer
3. build orchestrator
4. logger packaging
5. Codex ingestion/indexing
6. asset/snippet library
7. drag/drop intake flow
8. notification center
9. Git tool app

## Phase 3: AtlasAI Broker Layer

1. AI chat shell integration
2. local/Codex-first retrieval
3. debugging workflow from build logs
4. diff/change-summary review UI
5. approval/reject action loop
6. reusable fix/snippet promotion into Codex

## Phase 4: Editor Feature Growth

1. richer inspector widgets
2. graph/visual scripting foundation
3. asset pipeline editors
4. project-specific extension points
5. deeper multi-tool workflow

## Phase 5: External Project Integration

1. NovaForge loaded cleanly as external project/plugin
2. project-specific editors and data models
3. project-specific build targets
4. project-specific gameplay and UI work

## Roadmap Rule

Unless explicitly selected otherwise, prioritize tooling and Workspace standardization over new gameplay systems.
