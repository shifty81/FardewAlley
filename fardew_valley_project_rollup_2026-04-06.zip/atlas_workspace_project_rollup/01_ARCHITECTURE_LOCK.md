# Architecture Lock

## Core Rule

Atlas Workspace is a generic host environment. NovaForge and other games load into it as projects/plugins. Workspace core must remain game-agnostic.

## High-Level Layers

### 1. Atlas Workspace Core
Owns:
- shell/windowing host
- AtlasUI framework
- docking/panels
- command system
- notifications
- project loader
- editor framework
- build orchestration
- logging pipeline
- Codex ingestion
- AtlasAI broker entry points
- Git tool app
- shared services
- workspace-wide file intake
- theme/token/style systems

### 2. Engine / Runtime / Tooling Support Layer
Owns:
- common engine/editor services
- rendering/editor bridges
- ECS/editor glue where generic
- viewport framework
- asset pipelines
- plugin/extensibility interfaces
- serialization and reflection support if generalized

### 3. External Project Layer
Owns:
- NovaForge content and rules
- project-specific gameplay
- project-specific UI
- project-specific data schemas
- project-specific assets
- game-specific editor extensions
- build targets for that project

## Hard Boundaries

### Workspace core may reference:
- generic tooling contracts
- generic engine/editor support services
- project loading APIs
- plugin interfaces

### Workspace core may not hardcode:
- NovaForge gameplay classes
- farming logic
- space sim logic
- R.I.G. progression specifics
- project-specific HUD/menu rules
- project-specific item schemas

## Repo Direction

The current best direction is:
- keep Workspace generic
- allow NovaForge to exist as a separate project loaded into Workspace
- keep it logically detachable even if stored nearby during active development
- do not build NovaForge by default as part of Workspace core builds unless explicitly selected

## Build and Release Role

Atlas Workspace is the development and release environment.
NovaForge is developed, edited, built, packaged, and published through Workspace.
The final shipped game is output through this environment, but the game is not the Workspace.

## Editor Camera Lock

All editors should use a default ghost-style transparent actor with FPS-like camera behavior for viewports unless later overridden by tool/project context.

## Platform Lock

Treat Win32 as the baseline runtime and tooling platform direction for initial builds across tools and apps.

## UI Lock

AtlasUI is the standard UI framework across Workspace and tools.
Uniform standards should exist for:
- dock tabs
- panel chrome
- buttons
- tooltips
- rounded corners
- hover states
- pressed states
- shared theming/tokens
