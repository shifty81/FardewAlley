# Naming and Terminology Lock

## Locked Names

- `Atlas Workspace` = the generic editor/workspace platform
- `AtlasUI` = the standard UI framework
- `AtlasAI` = the visible broker AI layer
- `Codex` = archive/reuse/intake knowledge layer
- `R.I.G.` = the player suit/backpack assembly term in NovaForge

## Renames Already Captured

- use `AtlasAI` instead of old `Arbiter`
- prefer `Atlas Workspace` over `Atlas Suite` when discussing the unified all-C++ workspace direction
- avoid `MasterRepo.exe` as user-facing executable naming
- Atlas Workspace shell start bar label should be `Atlas`

## Naming Hygiene Rules

- Workspace/core naming must stay generic
- project/game names belong in project space
- do not name generic systems after NovaForge-only concepts
- avoid ambiguous mixed naming where tool/core and game/project are fused in one symbol or folder unless intentionally project-scoped

## Suggested Naming Guardrails

Generic:
- WorkspaceShell
- AtlasTheme
- AtlasCommandRegistry
- WorkspaceNotificationCenter
- ProjectLoader
- BuildOrchestrator
- LoggerArchive
- CodexIndex
- AtlasAIBroker

Project-scoped:
- NovaForgeWorld
- NovaForgeResearch
- NovaForgeRigSystem
- NovaForgeHUD
- NovaForgeBiomeRules
