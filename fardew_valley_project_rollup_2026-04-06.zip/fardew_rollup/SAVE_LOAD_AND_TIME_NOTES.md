# Save/Load and Time Notes

## Why these should come after several gameplay systems
Save/load becomes much more useful after the world actually contains:
- inventory contents
- crop stage data
- station processing state
- dropped world items
- day/time state
- placeables and container contents

## Save categories to persist
- player position and facing
- player inventories
- world clock and current day
- tile state changes such as tilled and watered ground
- planted crop instances with growth progress
- placed objects and stations
- container inventories
- active station jobs or timers
- dropped item entities that should survive save boundaries

## Reconstruction principle
Load should rebuild the runtime world from a combination of:
- static map/base layout data
- persisted delta state

## Time system minimum viable version
- minutes or ticks
- configurable day length
- time advancement hooks for crop growth and station processing
- start/end of day transitions
- event hooks for lighting and ambient changes

## Recommended rule
Do not overcomplicate the first time system with full seasons or weather unless they are directly needed by crop logic in the current slice.
