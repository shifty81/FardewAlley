# Roadmap Execution Order

## Phase 1. Core interaction baseline
- input mapping
- player movement
- collision and tile interaction probes
- interaction targeting rules
- inventory data model
- item grant and remove flow

## Phase 2. Shared action pipeline
- tool definitions
- action dispatch
- hit/result routing
- tile and object response handling
- common feedback hooks

## Phase 3. World economy and utility loop
- crafting recipes
- resource conversion
- storage containers
- item transfer rules
- placeable object definitions
- station activation and processing states

## Phase 4. Farming loop completion
- tillable soil states
- watered states
- planted crop states
- growth timers/stages
- harvest states and output generation
- regrowth rules if applicable

## Phase 5. Physical world presence
- world item entity class
- pickup collision and ownership rules
- drop spawning and despawn rules
- item stacking in world if desired
- visual feedback for item state

## Phase 6. Time and persistence
- world clock
- day progression
- optional weather hooks later
- save format and serializers
- load validation and world reconstruction

## Phase 7. Co-op
- split-screen player boot flow
- second player possession/spawn
- camera rules per player
- shared vs separate inventory decisions
- interaction authority rules
- later network abstraction if LAN is pursued
