# Gameplay Scope Lock

## Locked scope
- farming sim foundation
- top-down exploration and interaction
- inventory-driven loop
- tools routed through one shared action/result pipeline
- crops with growth and harvest states
- resource crafting and processing
- storage and transfer
- placeables and stations
- physical world items for pickup/drop
- world time and day/night progression
- world persistence through save/load
- local co-op support

## Influence lock
The intended feel can borrow from:
- Stardew Valley for progression loop, farming cadence, and cozy management structure
- Zelda: A Link to the Past for top-down readability, movement clarity, and environment interaction feel

## Not locked yet
These areas still need explicit decisions before hard implementation:
- exact render stack
- exact tile size and world coordinate rules
- exact save file format
- exact network architecture for later LAN / IP play
- exact authored content structure for maps, crops, items, NPCs, and events

## Explicit non-scope for this rollup
- Atlas Workspace core architecture
- NovaForge systems
- unrelated game or tooling assumptions from other project chats
