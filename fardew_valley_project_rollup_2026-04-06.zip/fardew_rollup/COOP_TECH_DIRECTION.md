# Co-op Technical Direction

## Current conclusion from thread
The user originally wanted join-by-IP LAN local co-op without split screen. The practical recommendation shifted toward split-screen because it is the fastest path to a playable cooperative version.

## Recommended implementation order
### First
Implement local split-screen co-op with:
- player one and player two spawn flow
- per-player camera framing
- interaction ownership rules
- inventory ownership policy
- pause/menu behavior in co-op

### Later
Abstract enough systems so a future LAN/IP mode could reuse:
- player controller abstraction
- shared world state authority model
- interaction events that do not assume single local owner
- save state that distinguishes players cleanly

## Key design decisions to lock
- whether players share money
- whether players share storage by default
- whether crafting consumes shared or local inventory
- how sleep/day advance works in co-op
- whether one player can pause for both
- whether both players can interact with same tile/object simultaneously

## Safe recommendation
For the first co-op pass:
- shared world
- separate player inventories
- shared containers and stations
- no global pause while multiple local players are active unless in menu state
- simple conflict rule where first successful interaction claims the object for that frame/window
