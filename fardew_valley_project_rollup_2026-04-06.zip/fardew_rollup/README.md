# Fardew Valley Repo Rollup

This pack is a distilled repo-drop summary for the **Fardew Valley** C++ project only.

Scope lock:
- Native Windows C++
- Stardew-like farming/life sim structure
- Zelda: A Link to the Past style influence in movement, readability, and feel
- Local co-op supported
- Split-screen accepted as the practical implementation path
- LAN / IP join can remain a later expansion path
- No Atlas Workspace assumptions in core game scope

Recommended repo drop path:
- `Docs/Fardew/`
- or `Spec/Fardew/`

Included documents:
- `FARDEW_PROJECT_SUMMARY.md`
- `SYSTEM_CHAIN_AND_BUILD_ORDER.md`
- `CURRENT_ARTIFACT_STATUS.md`
- `GAMEPLAY_SCOPE_LOCK.md`
- `ROADMAP_EXECUTION_ORDER.md`
- `GAP_AUDIT.md`
- `COOP_TECH_DIRECTION.md`
- `SAVE_LOAD_AND_TIME_NOTES.md`
