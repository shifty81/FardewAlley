# Fardew Valley Project Summary

## Project identity
Fardew Valley is a native Windows C++ farming/life sim project with strong inspiration from Stardew Valley and selected top-down action/adventure readability from Zelda: A Link to the Past.

## Core direction
The current direction is not to chase a giant engine-first architecture. The active path is to build the gameplay loop in practical vertical slices through compilable C++ starter packs and system passes.

## Target feel
- readable top-down world interaction
- tile-based or tile-aware interaction model
- satisfying farming loop
- strong item pickup / drop presence
- placeables, stations, storage, and processing
- day/night progression
- save/load continuity
- local co-op as a real supported play mode

## Platform direction
- native Windows C++
- local co-op prioritized over online complexity
- split-screen accepted as the most direct implementation path for co-op

## Co-op direction
Original desire included join-by-IP / LAN local co-op without split screen. Practical implementation direction shifted toward split-screen because it is the fastest path to a usable cooperative build. LAN / IP can still exist later as a follow-on multiplayer layer.

## Development style already established in this thread
The project flow was already being broken into execution-ready artifacts and starter packs such as:
- Input + Movement + Tile Interaction Pack v1
- Inventory + Item Grant Pack v1
- Tool System Pack v1
- Crop Growth + Harvest State Pack v1
- Pickup/Drop + World Item Entity Pack v1
- Day/Night + Time System Pack v1
- Save/Load World Consolidation Pass
- Multiplayer Interaction Layer later

This means the repo should be organized around clean gameplay subsystems with explicit integration points rather than broad vague planning.
