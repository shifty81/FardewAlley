# Gap Audit

## Likely still needed even if not fully specified in thread

### Core data and content
- item schema
- crop schema
- tool schema
- recipe schema
- station schema
- save schema
- map/world chunk or room schema

### Gameplay glue
- interaction prompt logic
- placement validation rules
- object health or break rules if destructibility exists
- player state machine for tool use and interaction lockouts
- animation event hooks
- audio event hooks

### UI
- inventory screen contract
- container UI contract
- crafting/station UI contract
- pause/menu flow
- co-op player HUD rules
- save/load menu flow

### Simulation
- weather system decision
- season system decision
- NPC and schedule system if desired
- animal system if desired
- economy/shop system if desired

### Technical
- deterministic identifiers for save/load restoration
- serialization boundaries between static map data and runtime data
- world item replication model for later networking
- input remapping strategy
- camera contract for split-screen and solo play
- asset pipeline and folder rules

## Immediate high-value missing specs
1. Item/Crop/Tool/Recipe data contracts
2. Tile state contract for soil/water/plant occupancy
3. World item entity contract
4. Save/load schema
5. Split-screen camera and player bootstrap rules
6. Station processing state machine

## What should not block immediate progress
- future online/LAN architecture
- deep NPC simulation
- advanced weather/season economy layers
- broad mod support questions
