# System Chain and Build Order

This reflects the active chain already established in the project discussion.

## Foundation chain
1. Input + Movement + Tile Interaction Pack v1
2. Inventory + Item Grant Pack v1
3. Tool System Pack v1

## Loop deepening chain
4. Crafting + Resource Processing Pack v1
5. Storage + Container Interaction Pack v1
6. Placeable Objects + Stations Pack v1
7. Station UI + Processing Loop Pack v1

## Farming and world presence chain
8. Crop Growth + Harvest State Pack v1
9. Pickup/Drop + World Item Entity Pack v1
10. Day/Night + Time System Pack v1
11. Save/Load World Consolidation Pass

## Multiplayer chain
12. Split-Screen Co-op Technical Spec v1
13. Split-Screen Co-op C++ Skeleton Pack v1
14. Multiplayer Interaction Layer later

## Why this order is logical
- movement and interaction must exist before meaningful item or tool flow
- inventory and item grant must exist before tool rewards and outputs matter
- tool routing should be unified early to prevent hardcoded per-tool drift
- crafting/storage/stations deepen the loop before farming scale increases
- crop growth matters more once inventory, tools, and world interaction exist
- physical world items make the game world feel real and support co-op readability
- time and save/load should land after several world systems exist so persistence covers actual gameplay state
- multiplayer should be layered after the core single-player simulation path is coherent
