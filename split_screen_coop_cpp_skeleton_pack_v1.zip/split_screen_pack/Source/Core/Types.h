#pragma once

#include <cstdint>

namespace atlas
{
    using u8  = std::uint8_t;
    using u16 = std::uint16_t;
    using u32 = std::uint32_t;
    using u64 = std::uint64_t;

    using s8  = std::int8_t;
    using s16 = std::int16_t;
    using s32 = std::int32_t;
    using s64 = std::int64_t;

    using f32 = float;
    using f64 = double;

    using EntityId = u32;
    using ZoneId = u32;
    using InventoryId = u32;

    constexpr EntityId InvalidEntityId = 0;
    constexpr ZoneId InvalidZoneId = 0;
    constexpr InventoryId InvalidInventoryId = 0;
}
