#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <array>
#include <optional>

using u8 = std::uint8_t;
using u16 = std::uint16_t;
using u32 = std::uint32_t;
using u64 = std::uint64_t;
using i32 = std::int32_t;
using i64 = std::int64_t;
using EntityId = u32;
using ZoneId = u32;

constexpr EntityId InvalidEntity = 0;
constexpr ZoneId InvalidZone = 0;
